#!/bin/bash

set -e

# ========================
# Rainbow Table Generator
# Nivel 1 + Nivel 2 + Nivel 3
# ========================

# ... contenido omitido por brevedad ...
