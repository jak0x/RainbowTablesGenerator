#!/bin/bash

# rainbowgen_installer.sh - Crea un paquete .deb para instalar RainbowGen como herramienta CLI

# ... contenido omitido por brevedad ...
